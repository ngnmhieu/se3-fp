# Morse Alfabet - wav-files

## Origin
These wave files have been converted from ogg files from this [Wikipedia Commons page](https://commons.wikimedia.org/wiki/Category:Audio_files_of_Morse_code_-_alphabet2).

## License
Permission is granted to copy, distribute and/or modify this document under the terms of the GNU Free Documentation License, Version 1.2 or any later version published by the Free Software Foundation; with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts. A copy of the license is included in the section entitled GNU Free Documentation License.

